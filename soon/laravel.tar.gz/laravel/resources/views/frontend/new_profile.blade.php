@extends('frontend.master')

@section('content')
    <!--slider***************************************-->
    <section class="modarsy-2">
        <section class="slider" style="height: 238px;">
            <div class="slid" style="height: 238px;">
                <div class="container">
                    <div class="row">
                        <div class="li-list">
                            <a href="#" class="home ">الرئيسية > </a>
                            <a href="#" class="conntact-my">نموذج التسجيل  > </a>
                            <a href="#" class="conntact-my active">إكمال الملف الشخصى </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="with-us text-center">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h2>
                            <a href="#">قم بمليء البيانات الخاصة بك لتكمل الملف الخاص بك</a>
                            <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على
                                الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة
                                لوريم إيبسوم أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم
                إيبسوم ....</p>
                        </h2>
                    </div>
                </div>
            </div>
        </section>
        <section class="modarsyy-1">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-xs-12">
                        <div class="form">
                            {!! Form::open(array('route' => 'profile.store', 'method' => 'POST','files' => true)) !!}

                            <input type="text" name="school" value="{{ old('school') }}" placeholder="المدرسة">


                            <textarea name="intro" id="" cols="30" rows="10" placeholder="مقدمة عن نفسك...">{{ old('intro') }}</textarea>

                            <select name="hear" id="">
                                <option selected disabled>من أين سمعت عنا</option>
                                <option {{ old('level') ? 'selected' : '' }} value="{{ old('hear') }}">{{ old('hear') }}</option>
                                <option value="من خلال صديق">من خلال صديق</option>
                                <option value="من خلال محرك بحث">من خلال محرك بحث</option>
                                <option value="من خلال إعلان مطبوع">من خلال إعلان مطبوع</option>
                                <option value="من خلال البريد الإلكترونى">من خلال البريد الإلكترونى</option>
                                <option value="من خلال رسالة على جوالك">من خلال رسالة على جوالك</option>
                            </select>

                            {!! Form::date('dbirth') !!}

                            {{--<input type="text" value="" name="age" placeholder="العمر">--}}

                            <label for="gender">
                                <input name="gender" type="radio" value="1"> ذكر
                            </label>

                            <label for="gender">
                                <input name="gender" type="radio" value="2"> أنثى
                            </label>

                            <select name="lang" id="">
                                <option selected disabled>لغة المادة</option>
                                <option {{ old('lang') === 'english' ? 'selected' : '' }} value="english">English</option>
                                <option {{ old('lang') === 'arabic' ? 'selected' : '' }} value="arabic">عربى</option>
                            </select>

                            @if(Auth::user()->type == 2)
                                {{Form::select('specialty',\App\Materials::pluck('title','slug'),old('specialty'),['class' => 'form-control'])}}
                                <input type="text" value="{{old('gen_exp')}}" name="gen_exp" placeholder="سنوات الخبره فى مجال تخصصك">
                                <input type="text" value="{{old('sch_exp')}}" name="sch_exp" placeholder="سنوات العمل فى مجال التدريس">
                                <input type="text" value="{{old('hour_rate')}}" name="hour_rate" placeholder="سعر الساعة بالدولار">
                                <input type="text" value="{{old('teach_time')}}" name="teach_time" placeholder="عدد الساعات المناسبة للتدريس فى اليوم من خلال موقعنا">
                                <select name="teach_hours" id="">
                                    <option disabled>مواعيد التدريس المناسبة</option>
                                    <option value="1" {{ old('teach_hours') === 1 ? 'selected' : '' }}>صباحا من 8ص وحتى 12م</option>
                                    <option value="2" {{ old('teach_hours') === 2 ? 'selected' : '' }}>منتصف اليوم من 12م وحتى 6م</option>
                                    <option value="3" {{ old('teach_hours') === 3 ? 'selected' : '' }}>مساءا من 6م وحتى 10م</option>
                                    <option value="4" {{ old('teach_hours') === 4 ? 'selected' : '' }}>فى أى وقت فى اليوم</option>
                                </select>
                            @elseif(Auth::user()->type == 3)
                                <select name="level" id="">
                                    <option disabled>المرحلة التعليمية</option>
                                    <option value="1" {{ old('level') === 1 ? 'selected' : '' }}>الصف الأول الإبتدائى</option>
                                    <option value="2" {{ old('level') === 2 ? 'selected' : '' }}>الصف الثانى الإبتدائي</option>
                                    <option value="3" {{ old('level') === 3 ? 'selected' : '' }}>الصف الأول الإبتدائى</option>
                                    <option value="4" {{ old('level') === 4 ? 'selected' : '' }}>الصف الثانى الإبتدائي</option>
                                </select>
                            @endif
                            <input id="pac-input" type="text" placeholder="Search Box"/>

                            {!! Form::label('photo', 'صورتك') !!}
                            {!! Form::file('photo') !!}
                            {!! Form::hidden('photo_w', 250) !!}
                            {!! Form::hidden('photo_h', 250) !!}
                            {!! Form::hidden('lat', null, ['id' => 'lat']) !!}

                            {!! Form::hidden('lng', null, ['id' => 'lng']) !!}

                            {!! Form::submit('حفظ البيانات') !!}

                            {!! Form::close() !!}
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12">
                        <p>رجاء قم بإختيار عنوانك على الخريطه </p>
                        <div id="map-canvas" style="height: 730px; width: 100%;">
                            <script type="text/javascript">
                                var $maperizer = $('#map-canvas').maperizer(Maperizer.MAP_OPTIONS);

                                $maperizer.maperizer('setCenter', {
                                    location: 'Saudi Arabia'
                                });

                                var latField = $('input#lat'),
                                    lngField = $('input#lng');

                                $maperizer.maperizer('attachEventsToMap', [{
                                        name: 'click',
                                        callback: function(event){
                                            $maperizer.maperizer('removeAllMarkers');
                                            $maperizer.maperizer('addMarker', {
                                                lat: event.latLng.lat(),
                                                lng: event.latLng.lng(),
                                            });
                                            latField.val(event.latLng.lat());
                                            lngField.val(event.latLng.lng());
                                        }
                                    }]
                                );

                            </script>

                        </div>

                    </div>

                </div>
            </div>

        </section>
    </section>







@endsection
