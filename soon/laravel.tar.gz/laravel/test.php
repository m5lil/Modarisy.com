<?php




if (strpos('http://l54.dev/test.php', 'test') !==false){
    echo"yes";


}
else{
    echo"no";
}