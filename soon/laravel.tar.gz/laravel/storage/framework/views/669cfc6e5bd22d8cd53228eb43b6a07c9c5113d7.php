<?php $__env->startSection('content'); ?>
    <h4 class="ui horizontal divider">
        خصائص الموقع
    </h4>

    <?php echo Form::open(['action' => 'SettingController@update', 'method' => 'post' ,'class' => 'ui form','files' => true]); ?>


    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="field">
            <label style="color: teal;"><?php echo e($setting->set_slug); ?> : </label>

            <?php if($setting->type == 1): ?>
                <?php echo Form::text($setting->set_name, $setting->value , ['class' => 'form-control']); ?>

            <?php elseif($setting->type == 2): ?>
                <?php echo Form::textarea($setting->set_name, $setting->value , ['class' => 'form-control']); ?>

            <?php elseif($setting->set_name == 'statue'): ?>
                <?php echo Form::select($setting->set_name,['online' => 'Online', 'offline' => 'Offline'] , $setting->value , ['class' => 'form-control']); ?>

            <?php elseif($setting->set_name == 'direction'): ?>
                <?php echo Form::select($setting->set_name,['rtl' => 'Right to left', 'ltr' => 'Left To Right'] , $setting->value , ['class' => 'form-control']); ?>


            <?php elseif($setting->set_name == 'fav_icon'): ?>
                <?php echo Form::file($setting->set_name); ?>

                <img src="<?php echo e(url('/uploads/thumb/' . $setting->value)); ?>" alt="thumbnail">

            <?php elseif($setting->set_name == 'logo'): ?>
                <?php echo Form::file($setting->set_name); ?>

                <img src="<?php echo e(url('/uploads/thumb/' . $setting->value)); ?>" alt="thumbnail">
            <?php endif; ?>

        </div>
        <br/>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="field">
        <input type="submit" name="submit" value="حفظ" class="ui teal button">
    </div>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>