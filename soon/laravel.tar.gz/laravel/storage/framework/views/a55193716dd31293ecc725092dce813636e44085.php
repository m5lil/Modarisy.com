<?php $__env->startSection('content'); ?>




    <h2 class="ui horizontal divider">
        <?php if(Request::is('dashboard/users/members/students')): ?>
            الطلاب
        <?php elseif(Request::is('dashboard/users/members/teachers')): ?>
            المدرسين
        <?php else: ?>
            الأعضاء
        <?php endif; ?>
    </h2>




    <table class="ui compact celled definition table">
        <thead class="full-width">
        <?php if(isset($users)): ?>

            <tr>
                <th>
                    #
                </th>
                <th>الإسم</th>
                <th>البريد الإلكترونى</th>
                <th>الحالة</th>
                <th>الصلاحية</th>
                <th>عمليات</th>
            </tr>
        <?php elseif(isset($teachers)): ?>
            <tr>
                <th>
                    #
                </th>
                <th>الإسم</th>
                <th>التخصص</th>
                <th>المرحلة</th>
                <th>الحالة</th>
                <th>عمليات</th>
            </tr>
        <?php endif; ?>

        </thead>
        <tbody>
        <?php if(isset($users) AND count($users)): ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="collapsing"><?php echo e($value->id); ?></td>
                      <td><?php echo e($value->first_name); ?> <?php echo e($value->last_name); ?></td>
                      <td><?php echo e($value->email); ?></td>
                      <td>
                          <i class="circle icon
                          <?php if(@$value->profile->statue != 0): ?>
                              green
                          <?php endif; ?>
                          "></i>
                      </td>
                      <td><?php echo e($value->roles()->pluck('name')); ?></td>
                      <td class="two wide">
                          <a href = "<?php echo e('/dashboard/users/' . $value->id); ?>/edit" class="ui left blue mini attached edit_form button icon"><i class="edit icon"></i></a>
                          <a href="<?php echo e(url('/dashboard/profiles/activate/') . '/' . $value->id); ?>"
                             class="ui right mini attached button icon"><i class="
                    <?php if(@$value->profile->statue == 0): ?>
                                      checkmark blue
                                  <?php else: ?>
                                      ban
                                  <?php endif; ?>
                                      icon"></i></a>
                          <a href = "<?php echo e('/dashboard/users/' . $value->id); ?>/delete"  class="ui right red mini attached delete_form button icon"><i class="trash icon"></i></a>
                      </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif( isset($teachers) AND count($teachers)): ?>
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="collapsing"><?php echo e($value->id); ?></td>
                      <td><?php echo e($value->FullName()); ?>

                      <td><?php echo e(@$value->profile->specialty); ?></td>
                      <td><?php echo e(@$value->profile->level); ?></td>
                      <td>
                          <i class="circle icon
                          <?php if(@$value->profile->statue != 0): ?>
                              green
                          <?php endif; ?>
                          "></i>
                      </td>
                      <td class="two wide">
                          <a href = "<?php echo e('/dashboard/users/' . $value->id); ?>/edit" class="ui left blue mini attached edit_form button icon"><i class="edit icon"></i></a>
                          <a href="<?php echo e(url('/dashboard/profiles/activate/') . '/' . $value->id); ?>"
                             class="ui right mini attached button icon"><i class="
                                  <?php if(@$value->profile->statue == 0): ?>
                                      checkmark blue
                                  <?php else: ?>
                                      ban
                                  <?php endif; ?>
                                      icon"></i></a>

                          <a href = "<?php echo e('/dashboard/users/' . $value->id); ?>/delete"  class="ui right red mini attached delete_form button icon"><i class="trash icon"></i></a>
                      </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="ui center aligned"> لا يوجد بيانات </td>
                </tr>
            <?php endif; ?>
        </tbody>

    </table>
<?php if(isset($users)): ?>
    <?php echo e($users->links()); ?>

<?php elseif(isset($teachers)): ?>
    <?php echo e($teachers->links()); ?>

<?php endif; ?>

   <?php $__env->startPush('scripts'); ?>
       
   <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>