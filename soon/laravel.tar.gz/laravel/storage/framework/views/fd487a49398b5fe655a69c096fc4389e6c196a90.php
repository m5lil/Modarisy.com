<!doctype html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="lE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e(setting('description')); ?>">
    <meta name="keywords" content="<?php echo e(setting('site_keywords')); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(setting('fav_icon')); ?>">
    <title><?php echo e(setting('site_name')); ?> | <?php echo $__env->yieldContent('title', 'Welcome you'); ?> </title>
    <link rel="stylesheet" href="<?php echo e(url('/css/font-awesome.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('/css/animate.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('/css/bootstrap.cs')); ?>s">
    <link rel="stylesheet" href="<?php echo e(url('/css/bootstrap-select.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('/css/bootstrap-rtl.cs')); ?>s">
    <link rel="stylesheet" href="<?php echo e(url('/css/ticker-style.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('/css/hover.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('/css/owl.carousel.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('/css/style.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('/css/style-ar.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('/css/media.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('/css/jquery-ui.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('/css/notie.min.css')); ?>"/>
    <script src="<?php echo e(url('/js/jquery-1.12.2.js')); ?>"></script>
    <script src="<?php echo e(url('/js/jquery-ui.min.js')); ?>"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBWymiO9Sk-Xp_8gVAuegZ3TpJ1FtbFLZI&amp;sensor=false&amp;signed_in=true&amp;libraries=geometry,places"></script>
    <script src="<?php echo e(asset('js/markerclusterer.js')); ?>"></script>
    <script src="<?php echo e(asset('js/maperizer/List.js')); ?>"></script>
    <script src="<?php echo e(asset('js/maperizer/Maperizer.js')); ?>"></script>
    <script src="<?php echo e(asset('js/maperizer/map-options.js')); ?>"></script>
    <script src="<?php echo e(asset('js/maperizer/jqueryui.maperizer.js')); ?>"></script>
    <script src="<?php echo e(asset('js/notie.min.js')); ?>"></script>

    
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
        window.notie
    </script>

</head>
<body>
<header>
    <div class="header">
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs12">
                        <div class="heder-top-left">
                            <div class="liste">
                                <div class="bootom">
                                    <ul class="list-inline">
                                        <li class="facebook-1 hvr-float">
                                            <a href="<?php echo e(setting('facebook')); ?>"><i class="fa fa-facebook"
                                                                                   aria-hidden="true"></i></a></li>
                                        <li class="twitter-1 hvr-float">
                                            <a href="<?php echo e(setting('twitter')); ?>"><i class="fa fa-twitter"
                                                                                  aria-hidden="true"></i></a></li>
                                        <li class="youtube-1 hvr-float">
                                            <a href="<?php echo e(setting('youtube')); ?>"><i class="fa fa-youtube"
                                                                                  aria-hidden="true"></i></a></li>
                                        
                                        
                                        
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6 col-sm-6 xs-12">

                        <button class="bot-com-2"><a href="#">English</a></button>

                        <div class="heder-top-right">
                            <p class="wats">
                                <?php echo e(setting('phone')); ?>

                                <span><i class="fa fa-whatsapp" aria-hidden="true"></i></span>
                            </p>
                            <p class="mail">
                                <?php echo e(setting('email')); ?>

                                <span class="icon-top"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
                            </p>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!--  header-bottom      -->

        <div class="head-b">
            <nav class="navbar navbar-default">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                            <div class="aside">
                                <?php if(file_exists(public_path() . '/uploads/' . setting('logo'))): ?>
                                    <img class=" img-logo-top-1 wow fadeInDown" data-wow-duration=" 2s"
                                         src="<?php echo e(url('/uploads/' . setting('logo'))); ?>">
                                <?php else: ?>
                                    <div style="font-size: 24px; margin-top: 45px; text-transform: uppercase;"><?php echo e(config('app.name', 'Modarrisi')); ?></div>
                                <?php endif; ?>
                            </div>
                        </a>
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav text-center nna">
                            <?php $__currentLoopData = App\Menu::orderBy('order','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $menuItem->parent_id == 0 ): ?>
                                    <li class="qw <?php echo e($menuItem->url ? '' : "dropdown menu-item-has-children"); ?>">
                                        <a href="<?php if($menuItem->children->isEmpty()): ?>
                                                <?php if(in_array($menuItem->url,\App\Page::pluck('slug')->toArray())): ?>
                                                    <?php echo e($menuItem->url); ?>

                                                <?php elseif(strpos($menuItem->url, '/') !== false ): ?>
                                                    <?php echo e($menuItem->url); ?>

                                                <?php else: ?>
                                                    http://<?php echo e($menuItem->url); ?>

                                                <?php endif; ?>
                                            <?php else: ?>
                                                #
                                            <?php endif; ?>" <?php echo e($menuItem->children->isEmpty() ? '' : "class=\"dropdown-toggle\" data-toggle=dropdown role=button aria-expanded=false"); ?>><?php echo e($menuItem->title); ?></a>


                                <?php endif; ?>

                                        <?php if( ! $menuItem->children->isEmpty() ): ?>
                                            <ul class="dropdown-menu sub-menu" role="menu">
                                                <?php $__currentLoopData = $menuItem->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="
                                                            <?php if(in_array($subMenuItem->url,\App\Page::pluck('slug')->toArray())): ?>
                                                                <?php echo e($subMenuItem->url); ?>

                                                            <?php elseif(strpos($subMenuItem->url, 'section/') !== false ): ?>
                                                                <?php echo e($subMenuItem->url); ?>

                                                            <?php else: ?>
                                                                    http://<?php echo e($subMenuItem->url); ?>

                                                            <?php endif; ?>
                                                                "><?php echo e($subMenuItem->title); ?></a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>


                    </div><!-- /.navbar-collapse -->
                    <div class="segin wow fadeInDown" data-wow-duration="2s">
                        <div class="bottom-headre">
                            <?php if(Auth::guest()): ?>
                                <button onclick="location.href='<?php echo e(url('/be_member')); ?>';" class="but-1 hvr-float-shadow">
                                    اشتراك
                                </button>
                                <button onclick="location.href='<?php echo e(url('/login')); ?>';" class="but-2 hvr-float-shadow">دخول
                                </button>
                            <?php else: ?>
                                <?php if(!Auth::user()->profile): ?>
                                    <button onclick="location.href='<?php echo e(url('/profile/create')); ?>';"
                                            class="but-1 hvr-float-shadow">أكمل ملفك
                                    </button>
                                <?php else: ?>
                                    <button onclick="location.href='<?php echo e(url('/')); ?>/home';"
                                            class="but-1 hvr-float-shadow">ملفك الشخصى
                                    </button>
                                <?php endif; ?>
                                <button type="submit"
                                        onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();"
                                        class="but-2 hvr-float-shadow">خروج
                                </button>
                                <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST"
                                      style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </nav>

        </div>
    </div>
</header>
<!-- end header-->

<script type="text/javascript">
    <?php if($errors->all()): ?>
        notie.alert({text: '<?php echo e(Html::ul($errors->all(),['class' => 'list1'])); ?>',time: 8,});
    <?php endif; ?>

    <?php if(Session::has('message')): ?>
        notie.alert({text: '<?php echo e(Session::get('message')); ?>'});
    <?php endif; ?>

</script>

<?php echo $__env->yieldContent('content'); ?>


<!--footer**************************************-->
<footer>
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <p class="first"> القائمة البريدية </p>
                    <hr>
                    <div class="form123">
                        <?php echo e(Form::open(array('action' => 'SubscribersController@Submit','method' => 'post'))); ?>

                        <?php echo e(Form::text('name',null,array('placeholder'=>'إسمك الكريم','class' => 'input1'))); ?>

                        <?php echo e(Form::text('email',null,array('placeholder'=>'بريدك الإلكترونى','class' => 'input1'))); ?>

                        <?php echo e(Form::submit('إشتراك!',['class' => 'subscribe btn btn-primary btn1'])); ?>

                        <?php echo e(Form::close()); ?>

                        <div class="content"></div>
                    </div>

                </div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <p class="first"> تابعنا على الفيس </p>
                    <hr>
                    <div class="fot-im">
                        <iframe src="https://www.facebook.com/plugins/page.php?href=<?php echo e(setting('facebook')); ?>%2F&tabs=timeline&width=260&height=270&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=418325768507501" width="260" height="270" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <p class="first"> اتصل بنا </p>
                    <hr>
                    <div class="conect-me">
                        <p><span>   <i class="fa fa-envelope-o" aria-hidden="true"></i> </span> <?php echo e(setting('email')); ?>

                        </p>
                        <p><span>   <i class="fa fa-phone" aria-hidden="true"></i> </span> <?php echo e(setting('phone')); ?> </p>
                        <p><span>   <i class="fa fa-user-plus" aria-hidden="true"></i> </span> <?php echo e(setting('postal')); ?>

                        </p>
                        <p><span>   <i class="fa fa-map-marker" aria-hidden="true"></i> </span> <?php echo e(setting('address')); ?>

                        </p>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <p class="first"> موقعنا على الخريطه </p>
                    <hr>

                    <div style='overflow:hidden;     margin-top: 35px;height:200px;width:100%;'>
                        <div id='gmap_canvas' style='height:200px;width:100%; border-radius: 8px;'></div>
                        <div>
                            <small><a href="http://embedgooglemaps.com">embedgooglemaps.com</a></small>
                        </div>
                        <div>
                            <small>
                                <a href="http://www.proxysitereviews.com /categories/myprivateproxy/">Myprivateproxy</a>
                            </small>
                        </div>
                        <style>#gmap_canvas img {
                                max-width: none !important;
                                background: none !important
                            }</style>
                    </div>
                    <script type='text/javascript'>function init_map() {
                            var myOptions = {
                                zoom: 10,
                                center: new google.maps.LatLng( <?php echo e(setting('lat')); ?>, <?php echo e(setting('lng')); ?> ),
                                mapTypeId: google.maps.MapTypeId.ROADMAP
                            };
                            map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);
                            marker = new google.maps.Marker({
                                map: map,
                                position: new google.maps.LatLng( <?php echo e(setting('lat')); ?>, <?php echo e(setting('lng')); ?> )
                            });
                            infowindow = new google.maps.InfoWindow({content: '<strong>المنصوره ساميه الجمل</strong><br>Riyad, Saudi Arabia<br>'});
                            google.maps.event.addListener(marker, 'click', function () {
                                infowindow.open(map, marker);
                            });
                            infowindow.open(map, marker);
                        }
                        google.maps.event.addDomListener(window, 'load', init_map);</script>

                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <p class="footer-bottom-p"><?php echo e(setting('copyright')); ?></p>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="footer-bottom-img">
                        <img src="<?php echo e(url('/images/footer-log-bottom.png')); ?>">
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>


<script src="<?php echo e(url('/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/bootstrap-rating.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(url('/js/jquery.ticker.js')); ?>"></script>
<script src="<?php echo e(url('/js/wow.min.js')); ?>"></script>
<script>new WOW().init();</script>
<script src="<?php echo e(url('/js/jquery.mixitup.js')); ?>"></script>
<script src="<?php echo e(url('/js/JavaScript-1.js')); ?>"></script>
<script type="text/javascript">


    
        $(document).ready(function () {
        $('div.content').hide();
        $('input.subscribe').click(function (e) {
            e.preventDefault();
            $.post('/subscribers/submit', {
                _token: $('input[name="_token"]').val(),
                name: $('input[name="name"]').val(),
                email: $('input[name="email"]').val()
            }, function ($data) {
                if ($data == '1') {
                    $('div.content').hide().removeClass('success error').addClass('success').html('تم إشتراكك بنجاح فى القائمة البريدية').fadeIn('fast');
                } else {
                    $('div.content').hide().removeClass('success error').addClass('error').html('هناك مشكلة الرجاء المحاولة فى وقت لاحق:<br /><br />' + $data).fadeIn('fast');
                }
            });
        });
        $('.form123').submit(function (e) {
            e.preventDefault();
            $('input[type="submit"]').click();
        });
    });
    $('input.rating').rating();

</script>

</body>
</html>
