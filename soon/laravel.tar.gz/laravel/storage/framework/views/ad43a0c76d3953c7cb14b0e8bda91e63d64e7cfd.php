<?php $__env->startSection('content'); ?>

    
    <?php $__env->startPush('css'); ?>
    <?php echo e(Html::style('plugins/jquery-ui/jquery-ui.min.css')); ?>

    <?php $__env->stopPush(); ?>

    <h4 class="ui horizontal divider">
        القائمة الرئيسية
    </h4>

    <div class="ui modal aeform">
        <div class="content">
            <?php echo e(Form::open(array('route' => 'menu.store', 'class' => 'ui form', 'id' => 'formpage'))); ?>

            <div class="ui top attached tabular menu">
                <?php  $count = 0; ?>
                <?php $__currentLoopData = config('app.locals'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $count++; ?>
                    <a class="<?php  if ($count == 1) {
                        echo ' active';
                    } ?> item" data-tab="<?php echo e($local); ?>"><?php echo e($local); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php  $count2 = 0; ?>

            <?php $__currentLoopData = config('app.locals'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $count2++; ?>

                <div class="ui bottom attached <?php  if ($count2 == 1) {
                    echo ' active';
                } ?> tab segment" data-tab="<?php echo e($local); ?>">
                    <div class="field">
                        <label>الاسم</label>
                        <input name="title[<?php echo e($local); ?>]" class="form-control" type="text" placeholder="العنوان">

                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="fields">
                <div class="twelve wide field">
                    <label>رابط خارجى</label>
                    <?php echo Form::text('url',  old('url'), array('id'=>'a', 'class'=>'form-control', 'placeholder' => 'أكتب الرابط بدون http://')); ?>

                </div>
                <div class="four wide field">
                    <label>رابط من صفحة</label>
                    <?php echo Form::select('url',  $pages, null, array('id'=>'b', 'class'=>'form-control')); ?>

                </div>
            </div>

            <div class="field">
                <label>الترتيب</label>
                <?php echo Form::text('order', old('order'), array('class'=>'form-control')); ?>

            </div>
            <div class="field">
                <label>الرابط الرئيسيى (الأب)</label>
                <?php echo Form::select('parent_id', $parents_menu , 0, array('class'=>'form-control')); ?>

            </div>

            <div class="actions">
                <button type="submit" class="ui positive right labeled icon button">حفظ
                    <i class="checkmark icon"></i>
                </button>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>

    <table class="ui compact celled definition   table">
        <tbody id="sortable">
        <?php if(count($menus)): ?>

            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($value->parent_id == 0): ?>
                    <tr id="item_<?php echo e($value->id); ?>">
                        <td class="collapsing"><a class="handle"><i class="sort icon"></i></a></td>
                        <td class="one wide"><?php echo e($value->order); ?></td>
                        <td><strong><?php echo e($value->title); ?></strong><br/>
                            <?php if(in_array( $value->url  , \App\Page::pluck('slug')->toArray() )): ?>
                                &nbsp;&nbsp;&nbsp;<strong>صفحة</strong> :
                                <small><?php echo e($value->url); ?></small>
                            <?php elseif(strpos($value->url, 'section/') ): ?>
                                &nbsp;&nbsp;&nbsp;<strong>قسم</strong> :
                                <small><?php echo e($value->url); ?></small>
                            <?php else: ?>
                                &nbsp;&nbsp;&nbsp;<strong>رابط</strong> : http://<?php echo e($value->url); ?>

                            <?php endif; ?>
                        </td>
                        <td class="two wide">
                            <a href="<?php echo e('/dashboard/menu/' . $value->id); ?>/edit"
                               class="ui left blue mini attached edit_form button icon"><i class="edit icon"></i></a>
                            <a href="<?php echo e('/dashboard/menu/' . $value->id); ?>/delete"
                               class="ui right red mini attached delete_form button icon"><i class="trash icon"></i></a>
                        </td>
                    </tr>
                    <?php if( ! $value->children->isEmpty() ): ?>
                        <?php $__currentLoopData = $value->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="font-size:12px; color:#2b2e55;">
                                <td class="collapsing"></td>
                                <td><i class="level up icon"></i> <?php echo e($subMenuItem->order); ?></td>
                                <td> &nbsp; <i class="level up icon"></i> <strong><?php echo e($subMenuItem->title); ?> </strong>
                                    (رابط
                                    فرعى)<br/> &nbsp;
                                    <?php if(in_array( $subMenuItem->url  , \App\Page::pluck('slug')->toArray() )): ?>
                                        &nbsp;&nbsp;&nbsp;<strong>صفحة</strong> :
                                        <small><?php echo e($subMenuItem->url); ?></small>
                                    <?php elseif(strpos($subMenuItem->url, 'section/') ): ?>
                                        &nbsp;&nbsp;&nbsp;<strong>قسم</strong> :
                                        <small><?php echo e($subMenuItem->url); ?></small>
                                    <?php else: ?>
                                        &nbsp;&nbsp;&nbsp;<strong>رابط</strong> : http://<?php echo e($subMenuItem->url); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="two wide">
                                    <a href="<?php echo e('/dashboard/menu/' . $subMenuItem->id); ?>/edit"
                                       class="ui left blue mini attached edit_form button icon"><i
                                                class="edit icon"></i></a>
                                    <a href="<?php echo e('/dashboard/menu/' . $subMenuItem->id); ?>/delete"
                                       class="ui right red mini attached delete_form button icon"><i
                                                class="trash icon"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="6" class="ui center aligned"> لا يوجد بيانات</td>
            </tr>
        <?php endif; ?>
        </tbody>

        <tfoot class="full-width">
        <tr>
            <th>
            </th>
            <th colspan="4">
                <button class="ui right floated small primary labeled icon form button">
                    <i class="user icon"></i> رابط جديد
                </button>
            </th>
        </tr>
        </tfoot>
    </table>



    <?php $__env->startPush('scripts'); ?>
    <?php echo e(HTML::script('plugins/jquery-ui/jquery-ui.min.js')); ?>


    <script type="text/javascript">

        $(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf"]').attr('value')
                }
            })
            $("#sortable").sortable({
                'containment': 'parent',
                'revert': true,
                helper: function (e, tr) {
                    var $originals = tr.children();
                    var $helper = tr.clone();
                    $helper.children().each(function (index) {
                        $(this).width($originals.eq(index).width());
                    });
                    return $helper;
                },
                'handle': '.handle',
                update: function (event, ui) {
                    $.post('<?php echo e(url('/dashboard/menu/order')); ?>', $(this).sortable('serialize'), function (data) {
                        console.log(data);
                        if (!data.success) {
                            alert('Whoops, something went wrong :/');
                        }
                    }, 'json');
                }
            });
            $(window).resize(function () {
                $('tbody tr').css('min-width', $('tbody').width());
            });

//            $("#sortable").disableSelection();
        });

        $('.aeform.modal')
            .modal('attach events', '.form.button');

        var dis1 = document.getElementById("a");
        dis1.onchange = function () {
            if (this.value != "" || this.value.length > 0) {
                document.getElementById("b").disabled = true;
            } else {
                document.getElementById("b").disabled = false;
            }
        }
        $(document).ready(function () {
            var dis1 = document.getElementById("a");
            if (dis1.value != "" || dis1.value.length > 0) {
                document.getElementById("b").disabled = true;
            } else {
                document.getElementById("b").disabled = false;
            }
        })

    </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>