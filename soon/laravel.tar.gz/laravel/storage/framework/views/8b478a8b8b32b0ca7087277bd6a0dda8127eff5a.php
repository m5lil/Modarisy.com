<?php $__env->startSection('content'); ?>

    


    <h4 class="ui horizontal divider">
        الرسائل
    </h4>
    <div class="ui modal eshow">
        <div class="header">إرسال نشرة بريدية</div>
        <div class="content">
            <div class="ui header" id="subject"></div>
            <?php echo e(Form::open(array('route' => 'subscribers.store','method' => 'post'))); ?>

            <div class="ui form bottom attached">
                <div class="field">
                    <label>العنوان الرئيسي</label>
                    <input name="subject" type="text" placeholder="العنوان">
                </div>
                <div class="field">
                    <label>مضمون النشرة</label>
                    <textarea name="message" class="textarea"></textarea>
                </div>
                <?php echo e(Form::submit('إرسال!',['class' => 'ui positive right labeled icon button'])); ?>

            </div>
            <?php echo e(Form::close()); ?>



        </div>
    </div>

    <table class="ui compact basic table">
        <thead class="full-width">
        <tr>
            <th>
                #
            </th>
            <th>الإسم</th>
            <th>الإيميل</th>
            <th>منذ</th>
            <th>عمليات</th>
        </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr
                    <?php if(!$value->read): ?>
                    class="positive"
                    <?php endif; ?>
            >
                <td class="collapsing">
                    <?php echo e($value->id); ?>

                </td>
                <td><strong><?php echo e($value->name); ?></strong></td>
                <td><?php echo e($value->email); ?></td>
                <td><?php echo e(\Date::parse($value->created_at)->diffForHumans()); ?></td>
                <td class="two wide">
                    <a href="<?php echo e(url('/dashboard/subscribers/' . $value->id)); ?>/delete"
                       class="ui right red mini attached button icon"><i class="trash icon"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="full-width">
        <tr>
            <th>
            </th>
            <th colspan="4">
                <button class="ui right floated small primary labeled icon show_msg form button">
                    <i class="send icon"></i> إرسال نشرة بريدية
                </button>
            </th>
        </tr>
        </tfoot>

    </table>




    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(url('plugins/tinymce/tinymce.min.js')); ?>" charset="utf-8"></script>

    <script type="text/javascript">


        $('.eshow.modal')
            .modal('attach events', '.form.button')
            .modal({
                onDeny: function () {
                    return false;
                }
            });



        tinymce.init({
            selector: '.textarea'
        });

    </script>
    <?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>