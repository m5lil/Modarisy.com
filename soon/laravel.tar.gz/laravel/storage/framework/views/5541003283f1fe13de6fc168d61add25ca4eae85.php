<?php $__env->startSection('content'); ?>




    <h4 class="ui horizontal divider">
        الصلاحيات
    </h4>

    <div class="ui modal aeform">
        <div class="content">
            <?php echo Form::open(array('action' => 'AbilityController@store', 'class' => 'ui form')); ?>


            		<div class="field">
            			<?php echo Form::label('name', 'الإسم (Eng & W/out spaces):'); ?>

            			<?php echo Form::text('name'); ?>

            		</div>

            		<div class="field">
            			<?php echo Form::label('title', 'الإسم:'); ?>

            			<?php echo Form::text('title'); ?>

            		</div>

            		<div class=" field">
                        
            			<?php echo Form::label('abilities', 'الصلاحيات:'); ?>

                        <?php echo Form::select('abilities[]', $abilities, null, array('id'=>'a', 'multiple' => true)); ?>

            		</div>
        </div>
        <div class="actions">
            <button type="submit" class="ui positive right labeled icon button">
                حفظ
                <i class="checkmark icon"></i>
            </button>
            <?php echo e(Form::close()); ?>

        </div>
    </div>



    <table class="ui compact celled definition table">
        <thead class="full-width">
            <tr>
                <th>
                    #
                </th>
                <th>الإسم</th>
                <th>الصلاحية</th>
                <th>عمليات</th>
            </tr>
        </thead>

        <tbody>
            <?php if(count($roles)): ?>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="collapsing"><?php echo e($value->id); ?></td>
                  <td><?php echo e($value->name); ?></td>
                  <td><?php echo e($value->title); ?></td>
                  <td class="two wide">
                      <a href = "<?php echo e('/dashboard/abilities/' . $value->id); ?>/edit" class="ui left blue mini attached edit_form button icon"><i class="edit icon"></i></a>
                      <a href = "<?php echo e('/dashboard/abilities/' . $value->id); ?>/delete"  class="ui right red mini attached delete_form button icon"><i class="trash icon"></i></a>
                  </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="6" class="ui center aligned"> لا يوجد بيانات </td>
            </tr>
        <?php endif; ?>
        </tbody>

        <tfoot class="full-width">
            <tr>
                <th>
                </th>
                <th colspan="5">
                    <button class="ui right floated small primary labeled icon form button">
                        <i class="user icon"></i> صلاحية جديدة
                    </button>
                </th>
            </tr>
        </tfoot>
    </table>



    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            $('.aeform.modal')
            .modal({
               onShow    : function(){
                   $('#a').select2({
                     placeholder: "أكتب ياللى بدك إياه",
                     tags : true,
                     language: "ar",
                     dir: "rtl"
                   });
               }
             })
              .modal('attach events', '.form.button')
            ;
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>