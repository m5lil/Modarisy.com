<?php $__env->startSection('content'); ?>


    <h4 class="ui horizontal divider">
الأقسام
    </h4>


    <div class="ui modal category_form">
        <div class="content">
            <?php echo e(Form::open(array('route' => 'categories.store', 'class' => 'ui form', 'id' => 'formpage'))); ?>


            <div class="ui top attached tabular menu">
                <?php  $count = 0; ?>
                <?php $__currentLoopData = config('app.locals'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $count++; ?>
                    <a class="<?php  if ($count == 1) {
                        echo ' active';
                    } ?> item" data-tab="<?php echo e($local); ?>"><?php echo e($local); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php  $count2 = 0; ?>

            <?php $__currentLoopData = config('app.locals'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $count2++; ?>

                <div class="ui bottom attached <?php  if ($count2 == 1) {
                    echo ' active';
                } ?> tab segment" data-tab="<?php echo e($local); ?>">
                    <div class="field">
                        <label>العنوان</label>
                        <input name="title[<?php echo e($local); ?>]" type="text" placeholder="العنوان">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="field">
                <label>عنوان الـ رابط</label>
                <input name="slug" type="text"
                       value="" placeholder="إسم القسم أو إختصار معبر لها باللغةالإنجليزية">
            </div>

            <div class="field">
                <select name="statue" class="ui dropdown">
                    <option value="1">منشورة</option>
                    <option value="0">غير منشورة</option>
                </select>
            </div>

        </div>
        <div class="actions">
            <button class="ui black deny button">
                إلغاء
            </button>
            <button class="ui positive right labeled icon button">
                حفظ
                <i class="checkmark icon"></i>
            </button>
        </div>
        <?php echo e(Form::close()); ?>

    </div>
    <table class="ui compact celled definition table">
        <thead class="full-width">
        <tr>
            <th>
                #
            </th>
            <th>عنوان القسم</th>
            <th>الحالة</th>
            <th>أنشأت منذ</th>
            <th>عمليات</th>
        </tr>
        </thead>

        <tbody>
        <?php if(isset($categories) AND count($categories)): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="item-<?php echo e($value->id); ?>">
                    <td class="collapsing">
                        <?php echo e($value->id); ?>

                    </td>
                    <td>
                        <strong class="content-<?php echo e($value->id); ?>"><?php echo e($value->title); ?></strong><br/><?php echo e(str_limit(strip_tags($value->body), 150, '...')); ?>

                    </td>
                    <td>
                        <i class="circle icon <?php if($value->statue): ?> green <?php endif; ?>"></i>
                    </td>
                    <td><?php echo e(\Date::parse($value->created_at)->diffForHumans()); ?></td>
                    <td>
                        <div class="ui tiny buttons">
                            <a href="<?php echo e(url('/dashboard/blog/categories/' . $value->id)); ?>/edit"
                               class="ui left blue mini attached button icon"><i class="edit icon"></i></a>
                            <a href="<?php echo e(url('/dashboard/blog/categories/' . $value->id)); ?>/delete"
                               class="ui right red mini attached button icon"><i class="trash icon"></i></a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="6" class="ui center aligned"> لا يوجد بيانات</td>
            </tr>
        <?php endif; ?>
        </tbody>

        <tfoot class="full-width">
        <tr>
            <th>
            </th>
            <th colspan="4">
                <button class="ui right floated small primary labeled icon form button">
                    <i class="user icon"></i> صفحة جديدة
                </button>
            </th>
        </tr>
        </tfoot>
    </table>



    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(url('plugins/tinymce/tinymce.min.js')); ?>" charset="utf-8"></script>
    <script type="text/javascript">
        $('.category_form.modal')
            .modal('attach events', '.form.button')
            .modal({
                onDeny: function () {
                    return false;
                }
            });
        ;
        tinymce.init({
            selector: '.textarea'
        });
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

    </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>