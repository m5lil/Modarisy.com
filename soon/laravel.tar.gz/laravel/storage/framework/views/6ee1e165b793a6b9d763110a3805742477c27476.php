<?php $__env->startSection('content'); ?>


    <h4 class="ui horizontal divider">
        الصفحات
    </h4>



    <div class="ui modal aeform">
        <div class="content">
            <?php echo e(Form::open(array('route' => 'pages.store', 'class' => 'ui form', 'id' => 'formpage','files' => true))); ?>


            <div class="ui top attached tabular menu">
                <?php  $count = 0; ?>
                <?php $__currentLoopData = config('app.locals'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $count++; ?>
                    <a class="<?php  if ($count == 1) {
                        echo ' active';
                    } ?> item" data-tab="<?php echo e($local); ?>"><?php echo e($local); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php  $count2 = 0; ?>

            <?php $__currentLoopData = config('app.locals'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $count2++; ?>

                <div class="ui bottom attached <?php  if ($count2 == 1) {
                    echo ' active';
                } ?> tab segment" data-tab="<?php echo e($local); ?>">
                    <div class="field">
                        <label>العنوان</label>
                        <input name="title[<?php echo e($local); ?>]" type="text" placeholder="العنوان">
                    </div>

                    <div class="field">
                        <label>المحتوى</label>
                        <textarea name="body[<?php echo e($local); ?>]" class="textarea"></textarea>
                    </div>
                    <div class="field">
                        <label>عنوان الـ SEO</label>
                        <input name="seo_title[<?php echo e($local); ?>]" type="text" placeholder="العنوان فى محركات البحث">
                    </div>
                    <div class="field">
                        <label>كلمات مفتاحية للـ SEO</label>
                        <input name="seo_keywords[<?php echo e($local); ?>]" type="text" placeholder="الكلمات المفتاحية">
                    </div>
                    <div class="field">
                        <label>وصف الـ SEO</label>
                        <input name="seo_description[<?php echo e($local); ?>]" type="text" placeholder="الوصف فى محركات البحث">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="field">
                <label>العنوان</label>
                <input name="slug" id="title" type="text"
                        placeholder="إسم الصفحة أو إختصار معبر لها باللغةالإنجليزية">
            </div>


            <div class="field">
                <?php echo Form::label('photo', 'الصورة*', array('class'=>'col-sm-2 control-label')); ?>

                    <?php echo Form::file('photo'); ?>

                    <?php echo Form::hidden('photo_w', 4096); ?>

                    <?php echo Form::hidden('photo_h', 4096); ?>

            </div>

            <div class="inline  field">
                <div class="ui toggle checkbox">
                    <?php echo Form::checkbox('statue', 1); ?>

                    <?php echo Form::label('statue', 'منشور'); ?>

                </div>
            </div>


        </div>
        <div class="actions">
            <button class="ui black deny button">
                إلغاء
            </button>
            <button class="ui positive right labeled icon button">
                حفظ
                <i class="checkmark icon"></i>
            </button>
        </div>
        <?php echo e(Form::close()); ?>

    </div>

    <table class="ui compact celled definition table">
        <thead class="full-width">
        <tr>
            <th>
                #
            </th>
            <th>عنوان الصفحة</th>
            <th>الحالة</th>
            <th>أنشأت منذ</th>
            <th>عمليات</th>
        </tr>
        </thead>

        <tbody>
        <?php if(count($pages)): ?>
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="item-<?php echo e($value->id); ?>">
                    <td class="collapsing">
                        <?php echo e($value->id); ?>

                    </td>
                    <td>
                        <strong class="content-<?php echo e($value->id); ?>"><?php echo e($value->title); ?></strong><br/><?php echo e(str_limit(strip_tags($value->body), 150, '...')); ?>

                    </td>
                    <td>
                        <i class="circle icon <?php if($value->statue): ?> green <?php endif; ?>"></i>
                    </td>
                    <td><?php echo e(\Date::parse($value->created_at)->diffForHumans()); ?></td>
                    <td>
                        <div class="ui tiny buttons">
                            <a href="<?php echo e(url('/dashboard/pages/' . $value->id)); ?>/edit"
                               class="ui left blue mini attached button icon"><i class="edit icon"></i></a>
                            <a href="<?php echo e(url('/dashboard/pages/' . $value->id)); ?>/delete"
                               class="ui right red mini attached button icon"><i class="trash icon"></i></a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="6" class="ui center aligned"> لا يوجد بيانات</td>
            </tr>
        <?php endif; ?>
        </tbody>

        <tfoot class="full-width">
        <tr>
            <th>
            </th>
            <th colspan="4">
                <button class="ui right floated small primary labeled icon form button">
                    <i class="user icon"></i> صفحة جديدة
                </button>
            </th>
        </tr>
        </tfoot>
    </table>

    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(url('plugins/tinymce/tinymce.min.js')); ?>" charset="utf-8"></script>
    <script type="text/javascript">
        $('.aeform.modal')
            .modal('attach events', '.form.button')
            .modal({
                onDeny: function () {
                    return false;
                }
            });
        ;
        tinymce.init({
            selector: '.textarea'
        });
//        $.ajaxSetup({
//            headers: {
//                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//            }
//        });

    </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>