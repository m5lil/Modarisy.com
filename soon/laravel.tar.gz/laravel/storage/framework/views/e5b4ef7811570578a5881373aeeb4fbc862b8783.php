<?php $__env->startSection('content'); ?>

    


    <h4 class="ui horizontal divider">
        <?php if(Request::is('dashboard/enquiries/statue/suspend')): ?>
            معلقة
        <?php elseif(Request::is('dashboard/enquiries/statue/active')): ?>
            مفعلة
        <?php elseif(Request::is('dashboard/enquiries/statue/in-progress')): ?>
            جارى العمل
        <?php elseif(Request::is('dashboard/enquiries/statue/done')): ?>
            منتهية
        <?php else: ?>
            الطلبات
        <?php endif; ?>
    </h4>

    <table class="ui compact basic table">
        <thead class="full-width">
        <tr>
            <th>
                #
            </th>
            <th>عنوان الطلب</th>
            <th>الحالة</th>
            <th>عدد المتقدمين</th>
            <th>صاحب الطلب</th>
            <th>إسم المعلم المختار</th>
            <th>منذ</th>
            <th>عمليات</th>
        </tr>
        </thead>

        <tbody>
        <?php if(Null != $enquiries): ?>
        <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="collapsing">
                    <?php echo e($value->id); ?>

                </td>
                <td><strong><?php echo e($value->subject); ?></strong></td>
                <td><?php echo e($value->Statue($value->statue)); ?></td>
                <td><?php echo e(count($value->applicants)); ?></td>
                <td><?php echo e(@$value->user->first_name); ?></td>
                <td><?php echo e(@$value->applicants->find($value->applicant_id)->user->first_name); ?></td>
                <td><?php echo e(\Date::parse($value->created_at)->diffForHumans()); ?></td>
                <td class="two wide">
                    <a href="<?php echo e(url('/dashboard/enquiries/') . '/' . $value->id . '/delete'); ?>"
                       class="ui left red mini attached  button icon"><i class="trash icon"></i></a>
                    <a href="<?php echo e(url('/dashboard/enquiries/activate/') . '/' . $value->id); ?>"
                       class="ui right mini attached button icon"><i class="
                    <?php if($value->statue == 0): ?>
                        checkmark blue
                    <?php else: ?>
                        ban
                    <?php endif; ?>
                        icon"></i></a>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>


    <?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
    </script>
    <?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>