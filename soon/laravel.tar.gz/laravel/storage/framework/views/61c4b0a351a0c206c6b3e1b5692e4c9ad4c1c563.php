<?php $__env->startSection('content'); ?>
    <!--slider***************************************-->
    <section class="slider" style="height: 238px;">
        <div class="slid" style="height: 238px;     padding: 40px 0px;">
            <div class="container">
                <div class="row">

                    <div class="col-md-12 col-xs-12">
                        
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--***************************************slider-->
    <secrion class="mod-arsy">
        <div class="container">
            <div class="row">
                <div class="col-md-4 dede">
                    <div class="first-mod-arsy">

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="slid-detils-img">
                                <img class="slid-detils" src="<?php echo e(url('/uploads/' . @$profile->photo)); ?>" alt="thumbnail">
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="slid-detils-wright">
                                <h2>
                                    <?php if($profile->user->type == 2): ?> أ / <?php elseif($profile->user->type == 3): ?> الطالب
                                    / <?php endif; ?>
                                    <?php echo e($profile->user->fullName()); ?></h2>
                                <p> المدينة <span class="detils-p-2">: <?php echo e($profile->user->city); ?> </span></p>
                                <p> التخصص <span class="detils-p-2">:<?php echo e($profile->specialty); ?></span></p>
                            </div>
                        </div>
                    </div>
                    <?php if($profile->user->type == 2): ?>
                        <p>التقييم <span class="detils-p-2"><input type="hidden" class="rating" disabled="disabled" value="<?php echo e($profile->getRating()); ?>"/> <?php echo e($profile->getRating()); ?> ( <?php echo e(count($profile->reviews()->get())); ?> تقييمات )</span></p>
                        <p>التخصص <span class="detils-p-2">: <?php echo e($profile->specialty); ?> $ / ساعة </span></p>
                        <hr>
                        <p> سعر الساعة <span class="detils-p-2">: <?php echo e($profile->hour_rate); ?> $ / ساعة </span></p>
                        <hr>
                        <p> لغة التدريس <span class="detils-p-2">: <?php echo e($profile->lang); ?> </span></p>
                        <hr>
                        <p> سنوات الخبره <span class="detils-p-2">: <?php echo e($profile->gen_exp); ?> </span></p>
                        <hr>
                        <p> سنوات العمل فى المدرسة <span class="detils-p-2">: <?php echo e($profile->sch_exp); ?> </span></p>
                        <hr>
                        <p> وقت التدريس المناسب <span
                                    class="detils-p-2">: <?php echo e(PreferedTime($profile->teach_time)); ?> </span></p>
                        <hr>
                        <hr>
                        <p> الدروس التى أنهاها <span
                                    class="detils-p-2">: <?php echo e(count($profile->user->applicants->where('statue',3))); ?> </span>
                        </p>
                        <hr>
                    <?php elseif($profile->user->type == 3): ?>

                    <?php endif; ?>
                    <p> المدرسة <span class="detils-p-2">: <?php echo e($profile->school); ?> </span></p>
                    <hr>
                    <p> السن <span class="detils-p-2">: <?php echo e($profile->age); ?> </span></p>
                    <hr>
                    <hr>

                    
                    
                    

                    
                    
                    
                    
                    
                    
                </div>
                <div class="col-md-8">
                    <div class="last-mod-arsy">
                        <div class="about-teatcher">
                            <h2>تعرف على</h2>

                            <p><?php echo e($profile->intro); ?></p>
                        </div>
                        <?php if($profile->user->type == 2): ?>
                            <div class="Request" style="margin-top: 20px;">
                                <div class="advertising1-car-1">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-2 col-xs-12 ">
                                            <button class="bot-2 filter active" data-filter=".category-2">
                                                <i class="fa fa-wpforms" aria-hidden="true"></i>
                                                جاري العمل علية
                                            </button>
                                        </div>
                                        <div class="col-md-4 col-sm-2 col-xs-12 ">
                                            <button class="bot-3 filter " data-filter=".category-3">
                                                <i class="fa fa-check-circle" aria-hidden="true"></i>
                                                تم تنفيذها
                                            </button>
                                        </div>

                                    </div>
                                </div>
                                <hr>
                            </div>
                            <div class="advertising2-car-2">
                                <div class="row" id="Container">
                                    <?php if(isset($progress_enquiries)): ?>
                                        <?php $__currentLoopData = $progress_enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-12 col-sm-12 col-xs-12 mix category-2" data-bound="">
                                                <div class="caarss ">

                                                    <h3><a href="#"><?php echo e($enquery->subject); ?></a></h3>
                                                    <p><?php echo e($enquery->comment); ?></p>
                                                    <p>الغرض من الطلب : <strong><?php echo e($enquery->target); ?></strong> |
                                                        الوقت المفضل :
                                                        <strong><?php echo e($enquery->PreferedTime($enquery->preferred_time)); ?></strong>
                                                    </p>
                                                    <hr>
                                                    <ul class="list-inline">
                                                        <li><a href="<?php echo e(url('/profile'). '/' .$enquery->user->id); ?>">الطالب :
                                                                <span><?php echo e($enquery->user->FullName()); ?></span></a></li>
                                                        <li>عدد الساعات : <span><?php echo e($enquery->total_hours); ?> ساعة</span></li>
                                                    </ul>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <?php if(isset($done_enquiries)): ?>
                                        <?php $__currentLoopData = $done_enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-12 col-sm-12 col-xs-12 mix category-3" data-bound="">
                                                <div class="caarss ">

                                                    <h3><a href="#"><?php echo e($enquery->subject); ?></a></h3>
                                                    <p><?php echo e($enquery->comment); ?></p>
                                                    <p>الغرض من الطلب : <strong><?php echo e($enquery->target); ?></strong> |
                                                        الوقت المفضل :
                                                        <strong><?php echo e($enquery->PreferedTime($enquery->preferred_time)); ?></strong>
                                                    </p>
                                                    <hr>
                                                    <ul class="list-inline">
                                                        <li><a href="<?php echo e(url('/profile'). '/' .$enquery->user->id); ?>">الطالب :
                                                                <span><?php echo e($enquery->user->FullName()); ?></span></a></li>
                                                        <li>عدد الساعات : <span><?php echo e($enquery->total_hours); ?> ساعة</span></li>
                                                    </ul>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php elseif($profile->user->type == 3): ?>
                            <div class="Request" style="margin-top: 20px;">
                                <div class="advertising1-car-1">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-2 col-xs-12 ">
                                            <button class="bot-1 filter active" data-filter=".category-1">
                                                <i class="fa fa-bars" aria-hidden="true"></i> طلبات الدروس
                                            </button>
                                        </div>
                                        <div class="col-md-4 col-sm-2 col-xs-12 ">
                                            <button class="bot-2 filter " data-filter=".category-2">
                                                <i class="fa fa-wpforms" aria-hidden="true"></i>
                                                جاري العمل علية
                                            </button>
                                        </div>
                                        <div class="col-md-4 col-sm-2 col-xs-12 ">
                                            <button class="bot-3 filter " data-filter=".category-3">
                                                <i class="fa fa-check-circle" aria-hidden="true"></i> تم
                                            </button>
                                        </div>

                                    </div>
                                </div>
                                <hr>
                            </div>
                            <div class="advertising2-car-2">
                                <div class="row" id="Container">
                                    <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-12 col-sm-12 col-xs-12 mix category-1" data-bound="">
                                            <div class="caarss ">

                                                <h3><a href="#"><?php echo e($enquery->subject); ?></a></h3>
                                                <p><?php echo e($enquery->comment); ?></p>
                                                <p>الغرض من الطلب : <strong><?php echo e($enquery->target); ?></strong> |                                                الوقت المفضل :
                                                    <strong><?php echo e($enquery->PreferedTime($enquery->preferred_time)); ?></strong>
                                                </p>
                                                <hr>
                                                <ul class="list-inline">
                                                    <li>عدد الساعات : <span><?php echo e($enquery->total_hours); ?> ساعة</span></li>
                                                </ul>

                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-12 col-sm-12 col-xs-12 mix category-2" data-bound="">
                                            <div class="caarss ">

                                                <h3><a href="#"><?php echo e($applicant->enquiry->subject); ?></a></h3>
                                                <p><?php echo e($applicant->brief); ?></p>
                                                <p>الأستاذ /  <?php echo e($applicant->user->FullName()); ?></p>
                                                <hr>
                                                <ul class="list-inline">
                                                    <li>عدد الساعات : <span><?php echo e($applicant->total_hours); ?> ساعة</span></li>
                                                </ul>

                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $done_applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-12 col-sm-12 col-xs-12 mix category-3" data-bound="">
                                            <div class="caarss ">

                                                <h3><a href="#"><?php echo e($applicant->enquiry->subject); ?></a></h3>
                                                <p><?php echo e($applicant->brief); ?></p>
                                                <p>الأستاذ /  <?php echo e($applicant->user->FullName()); ?></p>
                                                <hr>
                                                <ul class="list-inline">
                                                    <li>عدد الساعات : <span><?php echo e($applicant->enquiry->total_hours); ?> ساعة</span></li>
                                                    <li>سعر الساعة : <span>$<?php echo e($applicant->hour_price); ?> / ساعة</span></li>
                                                    <li>إجمالى السعر : <span><?php echo e($applicant->enquiry->total_hours * $applicant->hour_price); ?> دولار</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                    <div class="panel panel-default" style="margin-top: 20px;">
                        <div class="panel-heading">التقييمات</div>

                        <div class="panel-body">
                            <?php $__currentLoopData = $profile->reviews()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12 col-sm-12 col-xs-12 mix category-3"
                                     style="margin: 10px;background-color: #fff;">
                                    <div class="caarss ">
                                        <h4>
                                            <?php echo e($value->title); ?> - <small><?php echo e($value->author->FullName()); ?></small>
                                        </h4>
                                        <p><?php echo e(@$value->body); ?></p>
                                        <p><input type="hidden" readonly="readonly" class="rating" value="<?php echo e($value->rating); ?>">
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </secrion>
    <!--owl-slider**********************************-->
    <section class="owl-slider">
        <div class="owl-slid">
            <div class="owl-slid-hite text-center">
                <p>كيف تعمل</p>
                <img src="images/after.png">
            </div>
            <div class="container">
                <div class="owl-carousel">
                    <div class="item  wow fadeInUp" data-wow-duration="2s">
                        <div class="Clients">
                            <span class="Client-img">
                                <img src="images/clint.png">
                            </span>
                            <span class="Client-driv">
                                <span class="name">أحمد الالفى</span>
                                <span class="work">مدرس</span>
                            </span>
                        </div>
                        <div class="clint-right">
                            <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على
                                الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة
                                لوريم إيبسوم أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم
                                إيبسوم ....</p>
                            <i class="fa fa-comments" aria-hidden="true"></i>
                        </div>
                    </div>

                    <div class="item  wow fadeInUp" data-wow-duration="2s">
                        <div class="Clients">
                            <span class="Client-img">
                                <img src="images/clint.png">
                            </span>
                            <span class="Client-driv">
                                <span class="name">أحمد الالفى</span>
                                <span class="work">مدرس</span>
                            </span>
                        </div>
                        <div class="clint-right">
                            <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على
                                الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة
                                لوريم إيبسوم أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم
                                إيبسوم ....</p>
                            <i class="fa fa-comments" aria-hidden="true"></i>
                        </div>
                    </div>

                    <div class="item wow bounceIn" data-wow-duration="2s">
                        <div class="Clients">
                            <span class="Client-img">
                                <img src="images/clint.png">
                            </span>
                            <span class="Client-driv">
                                <span class="name">أحمد الالفى</span>
                                <span class="work">مدرس</span>
                            </span>
                        </div>
                        <div class="clint-right">
                            <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على
                                الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة
                                لوريم إيبسوم أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم
                                إيبسوم ....</p>
                            <i class="fa fa-comments" aria-hidden="true"></i>
                        </div>
                    </div>

                    <div class="item wow bounceIn" data-wow-duration="2s">
                        <div class="Clients">
                            <span class="Client-img">
                                <img src="images/clint.png">
                            </span>
                            <span class="Client-driv">
                                <span class="name">أحمد الالفى</span>
                                <span class="work">مدرس</span>
                            </span>
                        </div>
                        <div class="clint-right">
                            <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على
                                الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة
                                لوريم إيبسوم أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم
                                إيبسوم ....</p>
                            <i class="fa fa-comments" aria-hidden="true"></i>
                        </div>
                    </div>

                    <div class="item wow bounceIn" data-wow-duration="2s">
                        <div class="Clients">
                            <span class="Client-img">
                                <img src="images/clint.png">
                            </span>
                            <span class="Client-driv">
                                <span class="name">أحمد الالفى</span>
                                <span class="work">مدرس</span>
                            </span>
                        </div>
                        <div class="clint-right">
                            <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على
                                الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة
                                لوريم إيبسوم أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم
                                إيبسوم ....</p>
                            <i class="fa fa-comments" aria-hidden="true"></i>
                        </div>
                    </div>

                    <div class="item wow bounceIn" data-wow-duration="2s">
                        <div class="Clients">
                            <span class="Client-img">
                                <img src="images/clint.png">
                            </span>
                            <span class="Client-driv">
                                <span class="name">أحمد الالفى</span>
                                <span class="work">مدرس</span>
                            </span>
                        </div>
                        <div class="clint-right">
                            <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على
                                الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة
                                لوريم إيبسوم أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم
                                إيبسوم ....</p>
                            <i class="fa fa-comments" aria-hidden="true"></i>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>
    <!--**********************************owl-slider-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>