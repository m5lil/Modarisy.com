<?php $__env->startSection('content'); ?>
    <?php if($post): ?>
    <!--slider***************************************-->
    <section class="slider" style="height: 238px;">
        <div class="slid" style="height: 238px;">
            <div class="container">
                <div class="row">
                    <div class="li-list">
                        <a href="#" class="home ">الرئيسية</a>
                        <a href="#" class="conntact-my active"> <?php echo e($post->title); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="with-us">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <h2>
                        <a href="#"><?php echo e($post->title); ?></a>
                    </h2>
                    <br>
                    <?php if($post->photo): ?>
                    <img class="img-responsive" src="<?php echo e(url('/uploads/') . '/' .$post->photo); ?>" alt="">
                    <?php endif; ?>
                    <?php echo $post->body; ?>

                </div>
            </div>
        </div>
    </section>
    <?php else: ?>
        <section class="slider" style="height: 238px;">
            <div class="slid" style="height: 238px;">
                <div class="container">
                    <div class="row">
                        <div class="li-list">
                            <a href="#" class="home ">الرئيسية</a>
                            <a href="#" class="conntact-my active">صفحة غير موجوده</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <?php endif; ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>