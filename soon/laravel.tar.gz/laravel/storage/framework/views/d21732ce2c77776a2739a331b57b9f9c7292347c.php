<?php $__env->startSection('content'); ?>

    <section class="modarsyy-1">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    <div class="form">
                        <?php echo Form::open(array('route' => 'inbox.store', 'method' => 'POST')); ?>

                        <?php if(!Auth::check()): ?>
                        <?php echo Form::text('name',null,['placeholder' => 'إسمك الكريم']); ?>

                        <?php echo Form::text('email',null,['placeholder' => 'البريد الإلكترونى']); ?>

                        <?php echo Form::text('phone',null,['placeholder' => 'الجوال']); ?>

                        <?php endif; ?>
                        <?php echo Form::text('subject',null,['placeholder' => 'عنوان الرسالة']); ?>

                        <?php echo Form::textarea('body',null,['placeholder' => 'مضمون الرسالة']); ?>


                        <?php echo Form::submit('إرسل'); ?>




                        <?php echo Form::close(); ?>

                    </div>
                </div>

            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>