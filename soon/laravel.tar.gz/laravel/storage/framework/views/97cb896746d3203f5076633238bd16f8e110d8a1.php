<?php $__env->startSection('content'); ?>
    <?php if($posts): ?>
    <!--slider***************************************-->
    <section class="slider" style="height: 238px;">
        <div class="slid" style="height: 238px;">
            <div class="container">
                <div class="row">
                    <div class="li-list">
                        <a href="#" class="home ">الرئيسية</a>
                        <a href="#" class="conntact-my active">مقالات  <?php echo e($category_name); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="with-us">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12 col-sm-12 col-xs-12 mix category-3"
                             style="margin: 10px;background-color: #eee;">
                            <div class="caarss ">
                                <?php if($value->photo): ?>
                                    <div class="img-responsive" style="width: 100%; height: 300px; background: url(<?php echo e(url('/uploads/') . '/' .$value->photo); ?>);margin-top: -18px;background-size: cover;"></div>
                                <?php endif; ?>

                                <h3>
                                    <a href="<?php echo e(url('post/' . $value->id)); ?>"> <?php echo e($value->title); ?></a>
                                </h3>
                                <p><?php echo e(str_limit(strip_tags($value->body), 150, '...')); ?></p>
                                <hr>
                                <ul class="list-inline">
                                    <li>أنشأ منذ <?php echo e(\Date::parse($value->created_at)->diffForHumans()); ?></li>
                                </ul>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <?php else: ?>
        <section class="slider" style="height: 238px;">
            <div class="slid" style="height: 238px;">
                <div class="container">
                    <div class="row">
                        <div class="li-list">
                            <a href="#" class="home ">الرئيسية</a>
                            <a href="#" class="conntact-my active">لا يوجد مقالات فى هذا القسم</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <?php endif; ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>