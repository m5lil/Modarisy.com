<?php $__env->startSection('content'); ?>
    <!--slider***************************************-->
    <section class="modarsy-2">
        <section class="slider" style="height: 238px;">
            <div class="slid" style="height: 238px;">
                <div class="container">
                    <div class="row">
                        <div class="li-list">
                            <a href="#" class="home ">الرئيسية > </a>
                            <a href="#" class="conntact-my active">طلبات الدروس خاصة </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="with-us text-center">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h2>
                            <a href="#">نتيجة البحث</a>
                        </h2>
                    </div>
                </div>
            </div>
        </section>
        <section class="modarsyy-1">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-xs-12">

                        <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-12 col-sm-12 col-xs-12 mix category-3"
                                 style="margin: 10px;background-color: #fff;">
                                <div class="caarss ">
                                    <h3>
                                        <?php if($value->user): ?>
                                        <a href="<?php echo e(url('profile/' . $value->user->id)); ?>"> <?php echo e($value->user->fullName()); ?></a>
                                        <?php endif; ?>
                                    </h3>
                                    <p><?php echo e($value->intro); ?></p>
                                    <hr>
                                    <ul class="list-inline">
                                        <li><span class="t_hours"><?php echo e(@PreferedTime($value->teach_time)); ?></span>  الوقت المناسب له </li>
                                        <li><span class="t_hours"><?php echo e(@spec($value->specialty)); ?></span> التخصص </li>
                                    </ul>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>
            </div>

        </section>
    </section>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>