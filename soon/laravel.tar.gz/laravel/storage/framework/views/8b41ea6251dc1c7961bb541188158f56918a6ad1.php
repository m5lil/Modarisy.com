<?php $__env->startSection('content'); ?>

    


    <h4 class="ui horizontal divider">
        الرسائل
    </h4>

    <div class="ui modal eshow">
        <div class="header">محتوى الرساله</div>
        <div class="content">
            <div class="ui header" id="subject"></div>
            <p id="body"></p>
            <hr/>
            <span id="name"></span> -
            <span id="phone"></span> -
            <span id="email"></span>
        </div>
    </div>
    <div class="ui modal ereply">
        <div class="header">محتوى الرساله</div>
        <div class="content">
            <div class="ui header" id="subject"></div>
            <p id="name"></p>
            <p id="body"></p>
            <hr/>
            <p id="phone"></p>
            <p id="email"></p>
        </div>
    </div>

    <table class="ui compact basic table">
        <thead class="full-width">
        <tr>
            <th>
                #
            </th>
            <th>عنوان الرسالة</th>
            <th>المرسل</th>
            <th>إيميل المرسل</th>
            <th>منذ</th>
            <th>عمليات</th>
        </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $inbox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr
                    <?php if(!$value->read): ?>
                    class="positive"
                    <?php endif; ?>
            >

                <td class="collapsing">
                    <?php if(!$value->read): ?>
                        <div class="ui blue ribbon label"><i class="hide icon"></i></div>
                    <?php endif; ?>
                    <?php echo e($value->id); ?>

                </td>
                <td><?php echo e($value->subject); ?></td>
                <td><strong><?php echo e($value->name); ?></strong></td>
                <td><?php echo e($value->email); ?></td>
                <td><?php echo e(\Date::parse($value->created_at)->diffForHumans()); ?></td>
                <td class="two wide">
                    <a href='/dashboard/inbox/<?php echo e($value->id); ?>' class="ui left blue mini attached show_msg button icon"><i
                                class="unhide icon"></i></a>
                    <a href="<?php echo e($value->id); ?>" class="ui right red mini attached delete_msg button icon"><i
                                class="trash icon"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>



    <?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">


        // Show Message
        $('.show_msg').on('click', function (e) {
            e.preventDefault();
            var url = $(this).attr("href");
            $.get(url, function (data) {
                //success data
                $('#id').empty().append(data.id);
                $('#subject').empty().append(data.subject);
                $('#name').empty().append(data.name);
                $('#phone').empty().append(data.phone);
                $('#email').empty().append(data.email);
                $('#body').empty().append(data.body);

                $('.eshow.modal').modal('show');
            });
        });



        // TODO : Replay Message



        $('.delete_msg').on('click', function (e) {
            e.preventDefault();
            var target = $(this).attr("href");
            var self = $(this)

            swal({
                title: 'هل أنت متأكد?',
                text: "لن تكون قادر على التراجع !",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم, بقم بالحذف!',
                cancelButtonText: 'لا, قم بالإلغاء!',
                confirmButtonClass: 'ui blue button',
                cancelButtonClass: 'ui red button',
                buttonsStyling: false
            }).then(function () {
                $.ajax({
                    type: 'post',
                    url: 'inbox/delete',
                    data: {
                        '_token': $("input[name='_token']").val(),
                        'id': self.attr("href")
                    },
                    success: function (data) {
                        $('.item' + '-' + target).remove();
                    }
                });
                swal(
                    'تم الحذف!',
                    'لقد قمت بالحذف بنجاح.',
                    'success'
                )
            }, function (dismiss) {
                if (dismiss === 'cancel') {
                    swal(
                        'تم التراجع',
                        'السجل الذى كنت على وشك حذفه بأمان :)',
                        'error'
                    )
                }
            })
        });


    </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>