<?php $__env->startSection('content'); ?>




    <h4 class="ui horizontal divider">
        <?php if(Request::is('dashboard/applicants/statue/suspend')): ?>
            معلقة
        <?php elseif(Request::is('dashboard/applicants/statue/active')): ?>
            مفعلة
        <?php elseif(Request::is('dashboard/applicants/statue/in-progress')): ?>
            جارى العمل
        <?php elseif(Request::is('dashboard/applicants/statue/done')): ?>
            منتهية
        <?php else: ?>
            العروض
        <?php endif; ?>
    </h4>

    <table class="ui compact basic table">
        <thead class="full-width">
        <tr>
            <th>
                #
            </th>
            <th>عنوان الطلب</th>
            <th>الحالة</th>
            <th>سعر الساعة</th>
            <th>صاحب الطلب</th>
            <th> المعلم المتقدم</th>
            <th>منذ</th>
            <th>عمليات</th>
        </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr
                    <?php if(!$value->read): ?>
                    class="positive"
                    <?php endif; ?>
            >
                <td class="collapsing">
                    <?php echo e($value->id); ?>

                </td>
                <td><strong><?php echo e(@$value->enquiry->subject); ?></strong></td>
                <td><?php echo e($value->Statue($value->statue)); ?></td>
                <td><?php echo e($value->hour_price); ?></td>
                <td><?php echo e(@$value->enquiry->user->first_name); ?></td>
                <td><?php echo e(@$value->user->first_name); ?></td>
                <td><?php echo e(\Date::parse($value->created_at)->diffForHumans()); ?></td>
                <td class="two wide">
                    <a href="<?php echo e(url('/dashboard/applicant/') . '/' . $value->id . '/delete'); ?>"
                       class="ui left red mini attached delete_msg button icon"><i class="trash icon"></i></a>
                    <a href="<?php echo e(url('/dashboard/applicant/activate/') . '/' . $value->id); ?>"
                       class="ui right mini attached button icon"><i class="
                    <?php if($value->statue == 0): ?>
                        checkmark blue
                    <?php else: ?>
                        ban
                    <?php endif; ?>
                        icon"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


    <?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">

    </script>
    <?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>