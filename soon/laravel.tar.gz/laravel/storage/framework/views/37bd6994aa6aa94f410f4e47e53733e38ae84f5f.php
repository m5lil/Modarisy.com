<?php $__env->startSection('content'); ?>


    <h4 class="ui horizontal divider">
        تعديل مقال
    </h4>


    <?php echo e(Form::model($post, array('method' => 'PATCH','route' =>['posts.update', $post->id], 'class' => 'ui form', 'id' => 'formpage','files' => true))); ?>


    <div class="ui top attached tabular menu">
        <?php  $count = 0; ?>
        <?php $__currentLoopData = config('app.locals'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $count++; ?>
            <a class="<?php  if ($count == 1) {
                echo ' active';
            } ?> item" data-tab="<?php echo e($local); ?>"><?php echo e($local); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php  $count2 = 0; ?>

    <?php $__currentLoopData = config('app.locals'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $count2++; ?>

        <div class="ui bottom attached <?php  if ($count2 == 1) {
            echo ' active';
        } ?> tab segment" data-tab="<?php echo e($local); ?>">
            <div class="field">
                <label>العنوان</label>
                <?php echo Form::text('title[' . $local . ']', $post->translateOrNew($local)->title, array('class'=>'form-control')); ?>

            </div>

            <div class="field">
                <label>المحتوى</label>
                <?php echo Form::textarea('body[' . $local . ']', $post->translateOrNew($local)->body, array('class'=>'textarea')); ?>

            </div>
            <div class="field">
                <label>عنوان الـ SEO</label>
                <?php echo Form::text('seo_title[' . $local . ']', $post->translateOrNew($local)->seo_title, array('class'=>'form-control')); ?>


            </div>
            <div class="field">
                <label>كلمات مفتاحية للـ SEO</label>
                <?php echo Form::text('seo_keywords[' . $local . ']', $post->translateOrNew($local)->seo_keywords, array('class'=>'form-control')); ?>


            </div>
            <div class="field">
                <label>وصف الـ SEO</label>
                <?php echo Form::text('seo_description[' . $local . ']', $post->translateOrNew($local)->seo_description, array('class'=>'form-control')); ?>


            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <div class="field">
        <?php echo Form::label('category_id', 'القسم'); ?>

        <?php echo Form::select('category_id', \App\Category::translated()->get()->pluck('title','id'), $post->translateOrNew($local)->category_id); ?>

    </div>

    <div class="fields">
        <div class="fourteen wide field">
            <?php echo Form::label('photo', 'الصورة*', array('class'=>'col-sm-2 control-label')); ?>

            <?php echo Form::file('photo'); ?>

            <?php echo Form::hidden('photo_w', 4096); ?>

            <?php echo Form::hidden('photo_h', 4096); ?>

        </div>
        <div class="two wide field">
            <br>
            <img src="<?php echo e(url('/uploads/thumb/' . $post->photo)); ?>" alt="thumbnail">
        </div>
    </div>

    <div class="inline  field">
        <div class="ui toggle checkbox">
            <?php echo Form::checkbox('statue', 1); ?>

            <?php echo Form::label('statue', 'منشور'); ?>

        </div>
    </div>

    </div>
    <div class="actions">
        <button class="ui black deny button">
            إلغاء
        </button>
        <button class="ui positive right labeled icon button">
            حفظ
            <i class="checkmark icon"></i>
        </button>
    </div>
    <?php echo e(Form::close()); ?>


    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(url('plugins/tinymce/tinymce.min.js')); ?>" charset="utf-8"></script>
    <script type="text/javascript">
        tinymce.init({
            selector: '.textarea'
        });
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

    </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>