<?php $__env->startSection('content'); ?>
    <?php if($page): ?>
    <!--slider***************************************-->
    <section class="slider" style="height: 238px;">
        <div class="slid" style="height: 238px;">
            <div class="container">
                <div class="row">
                    <div class="li-list">
                        <a href="#" class="home ">الرئيسية</a>
                        <a href="#" class="conntact-my active"> <?php echo e($page->title); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="with-us">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <h2>
                        <a href="#"><?php echo e($page->title); ?></a>
                    </h2>

                    <br>
                    <?php if($page->photo): ?>
                    <img class="img-responsive" src="<?php echo e(url('/uploads/') . '/' .$page->photo); ?>" alt="">
                    <?php endif; ?>
                    <?php echo $page->body; ?>

                </div>
            </div>
        </div>
    </section>
    <?php else: ?>
        <section class="slider" style="height: 238px;">
            <div class="slid" style="height: 238px;">
                <div class="container">
                    <div class="row">
                        <div class="li-list">
                            <a href="#" class="home ">الرئيسية</a>
                            <a href="#" class="conntact-my active">صفحة غير موجوده</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <?php endif; ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>