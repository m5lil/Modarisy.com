<?php $__env->startSection('content'); ?>

    <section class="modarsy-2">
        <section class="with-us text-center">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h2>
                            <a href="#">تسجيل دخول</a>
                        </h2>
                    </div>
                </div>
            </div>
        </section>
        <section class="modarsyy-1">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-xs-12">
                        <div class="form">
                            <form role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input id="email" type="email" class="form-control" name="email"
                                       value="<?php echo e(old('email')); ?>" required autofocus placeholder="Your Email">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>

                                <input id="password" type="password" class="form-control" name="password" required placeholder="Your Password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>

                                <button type="submit" class="">
                                    تسجيل دخول
                                </button>
                                <br>
                                <label>
                                    <input type="checkbox"
                                           name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> تذكرنى
                                </label>
                                <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>">
                                    نسيت كلمة المرور?
                                </a>
                            </form>
                            <div style="clear: both;"></div>
                            <div class="text-center">
                                <button onclick="location.href='<?php echo e(url('/be_member')); ?>'" class="">
                                    إنشاء حساب جديد
                                </button>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </section>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>